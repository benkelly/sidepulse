SidePulse Dot firmware update - version 1.1.14

For SidePulse Dot only. Do not install on another SidePulse model.

1. Extract this ZIP on your computer.
2. Connect your SidePulse Dot and open its PulseDot drive.
3. Copy only FIRMWARE.BIN to the top level of that drive.
   Choose Replace if FIRMWARE.BIN already exists.
4. After copying finishes, leave the device connected and untouched for
   at least 10 seconds while it applies the update and restarts.
5. Reconnect the device, then open STATUS.TXT and check app_version 1.1.14.
   Reconnecting avoids a cached copy of STATUS.TXT on your computer.

FIRMWARE.BIN is already named correctly. Do not rename it or copy the ZIP
itself onto the drive. The other files in this ZIP are for your reference.

Normal copy/paste updates require a writable drive. Read-only storage policies
may prevent this installation method.
